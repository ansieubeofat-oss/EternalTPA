package me.eternal.tpa;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.*;

public class TPACommand implements CommandExecutor {

    public static Map<Player, Player> requests = new HashMap<>();
    public static Set<Player> auto = new HashSet<>();

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;

        if (cmd.getName().equalsIgnoreCase("tpauto")) {
            if (auto.remove(p)) p.sendMessage("§cTắt TP Auto");
            else {
                auto.add(p);
                p.sendMessage("§aBật TP Auto");
            }
            return true;
        }

        if (args.length != 1) {
            p.sendMessage("§c/tpa <tên>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            p.sendMessage("§cNgười chơi offline");
            return true;
        }

        requests.put(target, p);
        TPAGui.open(target, p);
        return true;
    }
}