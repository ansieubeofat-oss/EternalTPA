package me.eternal.tpa;

import org.bukkit.plugin.java.JavaPlugin;

public class EternalTPA extends JavaPlugin {
    @Override
    public void onEnable() {
        getCommand("tpa").setExecutor(new TPACommand());
        getCommand("tpauto").setExecutor(new TPACommand());
        getServer().getPluginManager().registerEvents(new TPAListener(), this);
        getLogger().info("EternalTPA v1.0 đã bật!");
    }
}