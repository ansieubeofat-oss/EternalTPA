package me.eternal.tpa;

import org.bukkit.plugin.java.JavaPlugin;

public class EternalTPA extends JavaPlugin {
    private static EternalTPA instance;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig(); // tạo config.yml nếu chưa tồn tại
        getCommand("tpa").setExecutor(new TPACommand());
        getCommand("tpauto").setExecutor(new TPACommand());
        getServer().getPluginManager().registerEvents(new TPAListener(), this);
        getLogger().info("EternalTPA v1.0 đã bật!");
    }

    public static EternalTPA getInstance() {
        return instance;
    }
}