package me.eternal.tpa;

import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.Material;

public class TPAListener implements Listener {

    @EventHandler
    public void click(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals("§6Yêu cầu TPA")) return;
        e.setCancelled(true);

        Player target = (Player) e.getWhoClicked();
        Player requester = TPACommand.requests.get(target);
        if (requester == null || e.getCurrentItem() == null) return;

        Material type = e.getCurrentItem().getType();
        if (type == Material.EMERALD) { requester.teleport(target); }
        else if (type == Material.REDSTONE) { /* từ chối */ }

        TPACommand.requests.remove(target);
        target.closeInventory();
    }
}