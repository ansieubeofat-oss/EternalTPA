package me.eternal.tpa;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;

public class TPAListener implements Listener {

    @EventHandler
    public void click(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals("§6Yêu cầu TPA")) return;
        e.setCancelled(true);

        Player target = (Player) e.getWhoClicked();
        Player requester = TPACommand.requests.get(target);
        if (requester == null || e.getCurrentItem() == null) return;

        if (e.getCurrentItem().getType() == Material.EMERALD)
            requester.teleport(target);

        TPACommand.requests.remove(target);
        target.closeInventory();
    }
}