package me.eternal.tpa;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import java.util.List;

public class TPAGui {

    public static void open(Player target, Player requester) {
        EternalTPA plugin = EternalTPA.getInstance();

        String title = plugin.getConfig().getString("gui.title");
        int size = plugin.getConfig().getInt("gui.size");

        Inventory inv = Bukkit.createInventory(null, size, title);

        // Head người chơi
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(requester);
        meta.setDisplayName("§e" + requester.getName());
        meta.setLore(List.of(plugin.getConfig().getString("gui.head_lore")));
        head.setItemMeta(meta);

        // Nút Đồng ý
        ItemStack accept = new ItemStack(Material.EMERALD);
        ItemMeta am = accept.getItemMeta();
        am.setDisplayName(plugin.getConfig().getString("gui.accept_name"));
        accept.setItemMeta(am);

        // Nút Từ chối
        ItemStack deny = new ItemStack(Material.REDSTONE);
        ItemMeta dm = deny.getItemMeta();
        dm.setDisplayName(plugin.getConfig().getString("gui.deny_name"));
        deny.setItemMeta(dm);

        inv.setItem(2, deny);
        inv.setItem(4, head);
        inv.setItem(6, accept);

        target.openInventory(inv);
    }
}