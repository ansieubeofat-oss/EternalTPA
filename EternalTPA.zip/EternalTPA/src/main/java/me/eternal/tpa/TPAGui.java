package me.eternal.tpa;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import java.util.List;

public class TPAGui {

    public static void open(Player target, Player requester) {
        Inventory inv = Bukkit.createInventory(null, 9, "§6Yêu cầu TPA");

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta hm = (SkullMeta) head.getItemMeta();
        hm.setOwningPlayer(requester);
        hm.setDisplayName("§e" + requester.getName());
        hm.setLore(List.of("§7Muốn dịch chuyển tới bạn"));
        head.setItemMeta(hm);

        ItemStack accept = new ItemStack(Material.EMERALD);
        ItemMeta am = accept.getItemMeta();
        am.setDisplayName("§a✔ Đồng ý");
        accept.setItemMeta(am);

        ItemStack deny = new ItemStack(Material.REDSTONE);
        ItemMeta dm = deny.getItemMeta();
        dm.setDisplayName("§c✖ Từ chối");
        deny.setItemMeta(dm);

        inv.setItem(2, deny);
        inv.setItem(4, head);
        inv.setItem(6, accept);

        target.openInventory(inv);
    }
}